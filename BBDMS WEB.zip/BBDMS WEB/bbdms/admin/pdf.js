<html>
    <head>              
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.6/jspdf.plugin.autotable.min.js"></script>
    </head>
    <body>
        <table class="table table-bordered" id="table">
            <tr>
                <th>Sr. No.</th>
                <th>Name</th>
                <th>Mob. No.</th>
                <th>Email Id</th>
            </tr>
            <tr>
                <td>1</td>
                <td>Alexa</td>
                <td>8098098901</td>
                <td>alexa@yahoo.com</td>
            </tr>
            <tr>
                <td>2</td>
                <td>Alexa</td>
                <td>8098098901</td>
                <td>alexa@yahoo.com</td>
            </tr>
            <tr>
                <td>3</td>
                <td>Alexa</td>
                <td>8098098901</td>
                <td>alexa@yahoo.com</td>
            </tr>
            <tr>
                <td>4</td>
                <td>Alexa</td>
                <td>8098098901</td>
                <td>alexa@yahoo.com</td>
            </tr>
            <tr>
                <td>5</td>
                <td>Alexa</td>
                <td>8098098901</td>
                <td>alexa@yahoo.com</td>
            </tr>
        </table>
        <button type="button" onclick="exportPdf()" class="btn btn-primary">Export To PDF</button>
    </body>
    <script>
         function exportPdf(){
            var pdf = new jsPDF();
            pdf.text(20,20,"Employee Details");
            pdf.autoTable({html:'#table',
                startY: 25,
                theme:'grid',
                columnStyles:{
                    0:{cellWidth:20},
                    1:{cellWidth:60},
                    2:{cellWidth:40},
                    3:{cellWidth:60}
                },
                bodyStyles: {lineColor: [1, 1, 1]},
                styles:{minCellHeight:10}
            });
            window.open(URL.createObjectURL(pdf.output("blob")))
         }
    </script>
</html>