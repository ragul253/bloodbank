	<nav class="ts-sidebar" style="background:#183047;">
			<ul class="ts-sidebar-menu" style="font-family: serif;
    font-size: revert;
}">
			
				<li class="ts-label" style="text-align: center;
    background: black;
    font: caption;
    color: antiquewhite;">Main</li>
				<li style="font-size: 17px" ><a href="dashboard.php" style="margin-top: 50px;"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
<li style="font-size: 17px"><a href="#" style="margin-top: 15px;"><i class="fa fa-files-o"></i> Blood Group</a>
<ul>
<li><a href="add-bloodgroup.php" >Add Blood Group</a></li>
<li><a href="manage-bloodgroup.php">Manage Blood Group</a></li>
</ul>
</li style="font-size: 17px;">


				
				<li style="font-size: 17px;"><a href="donor-list.php" style="margin-top: 15px;"><i class="fa fa-users"></i> Donor List</a></li>

				<li style="font-size: 17px;"><a href="manage-conactusquery.php" style="margin-top: 15px;"><i class="fa fa-desktop"></i> Manage Conatctus Query</a></li>
			<li style="font-size: 17px;"><a href="manage-pages.php" style="margin-top: 15px;"><i class="fa fa-files-o"></i> Manage Pages</a></li>
			<li style="font-size: 17px;"><a href="update-contactinfo.php" style="margin-top: 15px;"><i class="fa fa-files-o"></i> Update Contact Info</a></li>
			<li style="font-size: 17px;"><a href="blood-requests.php" style="margin-top: 15px;"><i class="fa fa-users"></i> Blood Requests</a></li>
<li style="font-size: 17px;"><a href="request-received-bydonar.php" style="margin-top: 15px;"><i class="fa fa-search"></i>Search Blood Request</a></li>

			</ul>
		</nav>