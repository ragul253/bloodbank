<div class="brand clearfix" style="text-align:center; background:#244363; "> 
	<a href="dashboard.php" style="font-size: xx-large; padding-top:1%; color:#fff; padding-left: 350px; font-family:serif;">BloodBank & Donor Management System </a>  
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			
			<li class="ts-account">
				<a href="#" style="background:bottom;"><img src="" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
				<ul><li><a href="profile.php" style="background:#151412;">Profile</a></li>
					<li><a href="change-password.php" style="background:#151412;">Change Password</a></li>
					<li><a href="logout.php" style="background:#151412;">Logout</a></li>
				</ul>
			</li>
		</ul>

	</div>
