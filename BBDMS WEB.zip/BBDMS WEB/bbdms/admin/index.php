<?php
session_start();
include('includes/config.php');
if(isset($_POST['login']))
{
$username=$_POST['username'];
$password=md5($_POST['password']);
$sql ="SELECT UserName,Password FROM tbladmin WHERE UserName=:username and Password=:password";
$query= $dbh -> prepare($sql);
$query-> bindParam(':username', $username, PDO::PARAM_STR);
$query-> bindParam(':password', $password, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
$_SESSION['alogin']=$_POST['username'];
echo "<script type='text/javascript'> document.location = 'dashboard.php'; </script>";
} else{
  
  echo "<script>alert('Invalid Details');</script>";

}

}

?>
<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>BloodBank & Donor Management System | Admin Login</title>
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<link rel="stylesheet" href="css/fileinput.min.css">
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<link rel="stylesheet" href="css/style.css">
</head>

<body>
</script>
	<div class="login-page bk-img" style="background-clip: url(video/The Components of Blood and Their Importance.mp4);
	">
	<video id="background-video" autoplay loop muted poster="https://assets.codepen.io/6093409/river.jpg" style="
    border-right-width: 200px;
    padding-bottom: -200;
    padding-right: 0px;
    height: 1000px;
    width: 1665px;">
      <source src="video/The Components of Blood and Their Importance.mp4" type="video/mp4">
    </video>
	
			
				
					
						<h1 class="text-center text-bold text-light mt-4x"
style="  color: skyblue; position: absolute;top: 150px;left: 50%;transform: translate(-50%, -50%);/* padding: 10px; *//* bottom: 1000000px; *//* margin-top: 0px; */">BloodBank & Donor Management System Admin login</h1>
						
								<form method="post" style="position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    padding: 10px;
	
    width: 800px;
    height: 10px;

}">

									<label for="" class="text-uppercase text-sm" style="color:red">Your Username </label>
									<input type="text" placeholder="Username" name="username" class="form-control mb">

									<label for="" class="text-uppercase text-sm" style="color:green">Password</label>
									<input type="password" placeholder="Password" name="password" class="form-control mb"  title="Must contain at least one number and one uppercase and lowercase letter,, and at least 6 or more characters">

								

									<button class="btn btn-primary btn-block" name="login" type="submit" style="background-color:green">LOGIN</button>
<a href="forgot-password.php" >Forgot Password</a>


                                        <a href="../index.php" class="btn btn-primary" style="
  pposition: absolute;
  top: 100;
  left: 50%;
  transform: translate(-50%, -50%);
  padding: 10px;
  top: 300px;
  position: absolute;
  top: 300px;
  left: 50%;
  transform: translate(-50%, -50%);
  padding: 10px;
  ">Back to Home</a>
                                    
								</form>
								
							
	
	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>

</body>

</html>